import { useState, useRef, useEffect } from 'react';
import { GoogleGenerativeAI } from '@google/generative-ai';
import { gsap } from 'gsap';

const AIChatBot = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');
  const orbRef = useRef(null);
  const chatRef = useRef(null);

  const toggleChat = () => {
    setIsOpen(!isOpen);
    if (!isOpen) {
      gsap.to(chatRef.current, { y: 0, opacity: 1, duration: 0.5 });
    } else {
      gsap.to(chatRef.current, { y: 300, opacity: 0, duration: 0.5 });
    }
  };

  const handleSend = async (e) => {
    e.preventDefault();
    if (!input.trim()) return;

    const userMessage = { sender: 'user', text: input };
    setMessages([...messages, userMessage]);
    setInput('');

    try {
      const apiKey = import.meta.env.VITE_GEMINI_API_KEY;
      if (!apiKey) throw new Error('API key is missing from .env file');

      const genAI = new GoogleGenerativeAI(apiKey);
      const model = genAI.getGenerativeModel({ model: 'gemini-1.5-flash' });

      const prompt = `You are an AI tutor for an educational website. Answer this question in a clear, concise, and futuristic tone: "${input}"`;
      const result = await model.generateContent(prompt);
      const responseText = await result.response.text();

      const botMessage = { sender: 'bot', text: responseText };
      setMessages((prev) => [...prev, botMessage]);
    } catch (error) {
      console.error('Chatbot API Error:', error.message);
      const errorMessage = { sender: 'bot', text: `Error: ${error.message}. Please try again.` };
      setMessages((prev) => [...prev, errorMessage]);
    }
  };

  useEffect(() => {
    gsap.from(orbRef.current, {
      scale: 0,
      opacity: 0,
      duration: 1,
      ease: 'elastic.out(1, 0.3)',
    });
  }, []);

  return (
    <>
      <div
        ref={orbRef}
        className="chat-orb"
        onClick={toggleChat}
        title="Ask me anything!"
      >
        AI
      </div>
      <div ref={chatRef} className={`chat-window ${isOpen ? 'open' : ''}`}>
        <div className="chat-header">
          <h3>AI Tutor</h3>
          <button onClick={toggleChat}>X</button>
        </div>
        <div className="chat-messages">
          {messages.map((msg, index) => (
            <div key={index} className={`message ${msg.sender}`}>
              {msg.text}
            </div>
          ))}
        </div>
        <form onSubmit={handleSend} className="chat-input">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Ask a question..."
            className="glow-input"
          />
          <button type="submit" className="supernova-btn">Send</button>
        </form>
      </div>
    </>
  );
};

export default AIChatBot;